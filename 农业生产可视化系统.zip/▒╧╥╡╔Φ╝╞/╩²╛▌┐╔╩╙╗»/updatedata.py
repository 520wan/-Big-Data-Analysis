import numpy as np
import pandas as pd
import pymysql

db_config = {
    "host": "localhost",
    "user": "root",
    "password": "123456",
    "database": "nysc",
}

connection = pymysql.connect(**db_config)

try:
    cursor=connection.cursor()
    query="SELECT * FROM agriculture"
    cursor.execute(query)
    data=cursor.fetchall()

    df=pd.DataFrame(data,columns=['id','area','value','unit','zb','updatetime'])
    update_query_template="""
    UPDATE agriculture SET area=%s, value=%s, unit=%s, zb=%s, updatetime=%s 
    WHERE id=%s"""
    
    update_data=[]
    for index,row in df.iterrows():
        update_data.append((row['area'],row['value'],row['unit'],row['zb'],row['updatetime'],row['id']))

    connection.commit()
    print("更新成功")

except Exception as e:
    print("更新失败")
    print(e)

finally:
    cursor.close()
    connection.close()