from django.db import models

# Create your models here.
class Agriculture(models.Model):
    id = models.BigIntegerField(verbose_name='id',primary_key=True)
    area =  models.CharField(verbose_name='area',max_length=255)
    value = models.CharField(verbose_name='value',max_length=255)
    unit = models.CharField(verbose_name='unit',max_length=255)
    zb = models.CharField(verbose_name='zb',max_length=255)
    updateTime = models.CharField(verbose_name='updateTime',max_length=255)
