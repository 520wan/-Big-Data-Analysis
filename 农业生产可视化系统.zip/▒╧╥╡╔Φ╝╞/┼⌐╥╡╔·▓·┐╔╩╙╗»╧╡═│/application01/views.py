from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.contrib.auth import authenticate, login as auth_login
from django.urls import reverse
from django.contrib.auth.forms import UserCreationForm
from .models import Agriculture

# Create your views here.

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        if username and password:
            user = authenticate(request, username=username, password=password)
            if user is not None:
                auth_login(request, user)
                return HttpResponseRedirect(reverse('index/'))  # 重定向到主页
            else:
                error_message = "用户名或密码错误"
                return render(request, 'login.html', {'error_message': error_message})
        else:
            error_message = "用户名和密码不能为空"
            return render(request, 'login.html', {'error_message': error_message})
    return render(request, 'login.html')

def index_view(request):
    return render(request,'index.html')

def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(request, username=username, password=raw_password)
            auth_login(request, user)
            return HttpResponseRedirect(reverse('index/'))  # 重定向到主页或其他页面
        else:
            return render(request, 'register/', {'form': form})
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})